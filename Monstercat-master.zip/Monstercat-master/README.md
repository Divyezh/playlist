# Monstercat Landing Page

## LANGUAGES USED

- HTML
- CSS, Flexbox

## PREVIEW 

This site is a fully responsive replica of one of Monstercat's dedicated artist pages. It is purely presentational and was made to test out my CSS skills shortly after learning the language.

![alt text](https://i.postimg.cc/hjFn0pyZ/main.png)
![alt text](https://i.postimg.cc/GpTrYZQs/songs.png)
![alt text](https://i.postimg.cc/1tpQ7wbm/related.png)

